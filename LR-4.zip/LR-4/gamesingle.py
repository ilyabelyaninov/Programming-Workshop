from gameclass import *

game = Game()